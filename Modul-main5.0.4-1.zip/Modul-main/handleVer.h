void handleVer() {
  String message;

  for ( uint8_t i = 0; i < server.args(); i++ ) {
    //message += " " + server.argName ( i ) + ": " + server.arg ( i ) + "\n";
    if(server.argName(i) == "szam"){
    }
    if(server.argName(i) == "hiszt"){
    }
    if(server.argName(i) == "relay"){
      boolean aktiv;
      if (server.arg(i) == "on") {
      }
      if (server.arg(i) == "off") {
      }
    }
  }
  
  message ="<html><head><title>ESP8266 Demo</title></head><body><h1>Hello from ESP8266!</h1><p>Ver: ";
  message += ver;
  message += "</p><p>";
  message += "<a href='restart.php?updates=true'>" + web_version + "</a>";
  message += String(urgent_update);
  message += "</p><p>";
  message += http_request_update;
  message += "</p><p>";
  message += web_hash;
  message += "</p><p>";
  message += String(ESP.getSketchMD5());
  message += "</p><p>";
  message += http_req_update_hash;
  message += "</p></body></html>";

  server.send ( 200, "text/html", message );
}
