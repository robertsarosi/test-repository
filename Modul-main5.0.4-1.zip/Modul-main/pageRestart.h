void pageRestart(){

    for ( uint8_t i = 0; i < server.args(); i++ ) {
      //message += " " + server.argName ( i ) + ": " + server.arg ( i ) + "\n";
      
  
      if(server.argName(i) == "updates"){
        egyseg.updates = true;
        saveConfig();
      }
    }
    delay(100);
    Serial.println("Reset....");
    ESP.restart();
}
