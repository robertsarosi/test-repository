String eltelt_ido() {

  String _eltelt_ido;
  
  int sec = millis() / 1000;
  int min = sec / 60;
  int hr = min / 60;
  int day = hr / 24;

  _eltelt_ido = String(day) + ", " + String(hr % 24) + ":" + String(min % 60) + ":"+ String(sec % 60);

  return _eltelt_ido;
}
