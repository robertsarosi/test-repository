



void oled_setup() {
  Heltec.begin(true /*DisplayEnable Enable*/, true /*Serial Enable*/);
  Heltec.display->init();
  Heltec.display->flipScreenVertically();
  Heltec.display->setFont(ArialMT_Plain_10);
}


void oled_loop(){
  if (egyseg.aktivok.oled_aktiv){
    Heltec.display->drawString(0,0,"Hello World!");
    Heltec.display->display(); 
  } else {
    Heltec.display->clear();
  }
}
