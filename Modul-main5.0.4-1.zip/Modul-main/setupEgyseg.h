
void setupEgyseg(){


//  struct homeros {
//  int id0;
//  byte id1;
//  String names;
//  float fdata;
//  String sdata;
//  int idata;
//  int dbszam;
//  float hiszt;
//  boolean aktiv;
//  boolean idokep_aktiv;
//  boolean mysql_aktiv;
//  String mysql_path;
//  String mysql_data;
//  boolean ds18b20_aktiv;
//  boolean lm50c_aktiv;
//  boolean controller_aktiv;
//};


  if (!loadConfig()) {
    egyseg.id0 = 555;
    egyseg.id1 = 101;
    egyseg.names = "Nincs_nev";
    egyseg.dbszam = 0;
    egyseg.hiszt = 0;
    egyseg.aktiv = false;
    egyseg.mysql_path = "";
    egyseg.mysql_data = "";
    egyseg.aktivok.idokep_aktiv = false;
    egyseg.aktivok.mysql_aktiv = false;
    egyseg.aktivok.ds18b20_aktiv = false;
    egyseg.aktivok.lm50c_aktiv = false;
    egyseg.aktivok.controller_aktiv = false;
    egyseg.aktivok.oled_aktiv = false;
    } else {
    Serial.println("Config loaded");
  }
}
