boolean relay, old_relay;
uint8_t messageBE[] = {0xA0, 0x01, 0x01, 0xA2};
uint8_t messageKI[] = {0xA0, 0x01, 0x00 , 0xA1};

void relay_setup() {
  ;
}

void relay_loop(boolean _state) {
  if (!_state == old_relay) {
    if (_state) {
      Serial.write(messageBE, sizeof(messageBE));
    } else {
      Serial.write(messageKI, sizeof(messageKI));
    }
  }
  old_relay = _state;
}
