<?php
	header ('Content-type: text/html; charset=utf-8');
	//include("conec.php");
	//$link=Conection();
	//$database=Master_Conection();
	//$timeout = 3600;
	//include("function.php");

		
?>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
   <title>Digital Ic storage</title>
   <link rel="stylesheet" href="css/base.css">
   <link rel="stylesheet" href="css/digitallist.css">
   <link rel="stylesheet" href="css/table.css">
   <link rel="stylesheet" href="css/tabsuj.css">
   <link rel="stylesheet" href="css/navbar.css">
   <link rel="stylesheet" href="css/menu.css">
   
   
<script language="javascript" type="text/javascript" src="jquery/jquery.js">
</script>
<script language="javascript" type="text/javascript">
	function bodyxy()
	{
	   if (window.innerWidth > 280)
	   {
			//document.body.style.width = "1560px";
			//document.body.style.height = "960px";
			document.getElementById('block').style.width = document.getElementById('wrapper').style.width;
			document.getElementById('hiddenwindow').style.left = 193 + document.getElementById('szoveg').offsetLeft;
			document.getElementById('hiddenwindow').style.top = 135 + document.getElementById('szoveg').offsetTop;
	   }
	   else {
			//document.body.style.width = "1024px";
	   }
	}
	//window.onload = bodyxy;
	//window.onresize = bodyxy;

</script>

<script type="text/javascript">
	function parseURLParams(url) {
		var queryStart = url.indexOf("?") + 1,
			queryEnd   = url.indexOf("#") + 1 || url.length + 1,
			query = url.slice(queryStart, queryEnd - 1),
			pairs = query.replace(/\+/g, " ").split("&"),
			parms = {}, i, n, v, nv;

		if (query === url || query === "") return;

		for (i = 0; i < pairs.length; i++) {
			nv = pairs[i].split("=", 2);
			n = decodeURIComponent(nv[0]);
			v = decodeURIComponent(nv[1]);

			if (!parms.hasOwnProperty(n)) parms[n] = [];
			parms[n].push(nv.length === 2 ? v : null);
		}
		return parms;
	}
	
	function load_home() {
		var html = parseURLParams(window.location.href).p;
		document.getElementById("szoveg").innerHTML='<object type="text/html" data="' + html + '" style="width:100%; height: 100%;" ></object>';
		
	}
</script>

<script language="javascript" type="text/javascript" src="jquery/activate 2.3.js"></script>
<script language="javascript" type="text/javascript" src="jquery/newrow.js"></script>
<script language="javascript" type="text/javascript" src="jquery/alap1.0.js"></script>
</head>
<body>
	<div id="wrapper">
		<div id="block"></div>
		<div id="fejlec">
			<div id="webcim" style="float: left;">
			    
			</div>
			<div id="belepes" style="float: right; color: white;">
				<?php
				?>
			</div>
			<div class="clear"></div>
		</div>
		<div id="navbar" class="navbar">
			<ul>
				<li onclick="location.href='index.php?p=index.html'">kezdőlap</li>
				<li onclick="location.href='index.php?p=version.php'">version</li>
			</ul>
		</div>
		<div id="test">
			<div id="menu">
			</div>
			<div id="szoveg">
			</div>
			<div id="hiddenwindow" style="top: 27%; left: 27%;">
				<iframe name="hiddeniframe" id="hiddeniframe" width="444px" height="394px"></iframe>
			</div>
		</div>
		<script>
			load_home();
		</script>
		<div class="clear"></div>
		<div id="navbar2" class="navbar">
			<ul>
				<li onclick="location.href='index.php?p=index.html'">kezdőlap</li>
				<li onclick="location.href='index.php?p=version.php'">version</li>
			</ul>
		</div>
		<div id="lablec">
		</div>
	</div>
	<div id="seged" style="display:none">
	</div>
</body>
</html>