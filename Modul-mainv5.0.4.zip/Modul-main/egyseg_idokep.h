const char* idokep_host = "automata.idokep.hu";
const char* idokep_url = "/sendws.php"; //?user=robertsarosi&pass=Conti1981&utc=0&hom=";

void idokep_setup(){
  ;
}

void idokep_loop(){
      client1.stop();          
      if (client1.connect(idokep_host, 80)) {
        String url = idokep_url;
		url += "?";
		url += "user=" + egyseg.parameterek.idokep_user;
		url += "&";
		url += "pass" + egyseg.parameterek.idokep_passw;
		url += "&utc=0&hom=";
        url += String(ds18b20_tempC, 2);
        url += "&rh=&csap=&p=&tipus=WS2350";
        client1.print(String("GET ") + url + " HTTP/1.1\r\n" +
                     "Host: " + idokep_host + "\r\n" + 
                     "Connection: keep-alive\r\n" +
                     "Cache-Control: max-age=0\r\n"+
                     "Upgrade-Insecure-Requests: 1\r\n" +
                     "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36\r\n" +
                     "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8\r\n" +
                     "\r\n");
      } else {Serial.println("connection failed"); client1.stop(); WiFiClient client1;}  
}
