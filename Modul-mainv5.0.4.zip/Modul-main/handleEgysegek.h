

void handleEgysegek_Lekeres() {
  String message;
  boolean serverArg_volt = false;
  

  for ( uint8_t i = 0; i < server.args(); i++ ) {
    message += " " + server.argName ( i ) + ": " + server.arg ( i ) + "\n";
    serverArg_volt = true;

    if(server.argName(i) == "id0"){
      egyseg.id0 = server.arg(i).toInt();
    }

    if(server.argName(i) == "id1"){
      egyseg.id1 = server.arg(i).toInt();
    }
    
    if(server.argName(i) == "name"){
      egyseg.names = server.arg(i);
    }
    
    if(server.argName(i) == "szam"){
        egyseg.dbszam = server.arg(i).toInt();
    }
    
    if(server.argName(i) == "hiszt"){
        egyseg.hiszt = server.arg(i).toFloat();
    }
    if(server.argName(i) == "ds18b20"){
      if (server.arg(i) == "on") {
        egyseg.aktivok.ds18b20_aktiv = true;
      }
      if (server.arg(i) == "off") {
        egyseg.aktivok.ds18b20_aktiv = false;
      }
    }

    if(server.argName(i) == "lm50c"){
      if (server.arg(i) == "on") {
        egyseg.aktivok.lm50c_aktiv = true;
      }
      if (server.arg(i) == "off") {
        egyseg.aktivok.lm50c_aktiv = false;
      }
    }

    if(server.argName(i) == "mysql"){
      if (server.arg(i) == "on") {
        egyseg.aktivok.mysql_aktiv = true;
      }
      if (server.arg(i) == "off") {
        egyseg.aktivok.mysql_aktiv = false;
      }
    }

    if(server.argName(i) == "controller"){
      if (server.arg(i) == "on") {
        egyseg.aktivok.controller_aktiv = true;
      }
      if (server.arg(i) == "off") {
        egyseg.aktivok.controller_aktiv = false;
      }
    }

    if(server.argName(i) == "idokep"){
      if (server.arg(i) == "on") {
        egyseg.aktivok.idokep_aktiv = true;
      }
      if (server.arg(i) == "off") {
        egyseg.aktivok.idokep_aktiv = false;
      }
    }

    if(server.argName(i) == "oled"){
      if (server.arg(i) == "on") {
        egyseg.aktivok.oled_aktiv = true;
      }
      if (server.arg(i) == "off") {
        egyseg.aktivok.oled_aktiv = false;
      }
    }

    if(server.argName(i) == "onewire_pin"){
      if (server.arg(i) == "0") {
        egyseg.parameterek.onewire_pin = 0;
      }
      if (server.arg(i) == "2") {
        egyseg.parameterek.onewire_pin = 2;
      }
    }
    
    if(server.argName(i) == "relay"){
        if (relay) {
          message = "on";
        } else {
          message = "off";
        }
    }
  }

  //if (serverArg_volt) saveConfig();
  
  
  server.send ( 200, "text/html", message );
}
