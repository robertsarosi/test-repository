const char* host = "berobiskazan.hu";



void sendmysql(){
      client1.stop();
      if (client1.connect(host, 80)) {       
        String url = "/AktivHaz/add.php?egyseg=";
        url += String(egyseg.id0, HEX) + String(egyseg.id1, HEX);
        url += "&allapot=";
        url += egyseg.names;
        url += "&hofok=";
        url += String(ds18b20_tempC,3);
        
        Serial.print("Requesting URL: ");
        Serial.println(url);
        
        client1.print(String("GET ") + url + " HTTP/1.1\r\n" +
                     "Host: " + host + "\r\n" + 
                     "Connection: keep-alive\r\n" +
                     "Cache-Control: max-age=0\r\n"+
                     "Upgrade-Insecure-Requests: 1\r\n" +
                     "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36\r\n" +
                     "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8\r\n" +
                     "\r\n");
      } else {Serial.println("connection failed"); client1.stop(); WiFiClient client1;}
}
