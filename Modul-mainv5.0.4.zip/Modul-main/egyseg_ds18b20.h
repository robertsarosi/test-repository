#define ONE_WIRE_BUS0 0
#define ONE_WIRE_BUS2 2

OneWire oneWire0(ONE_WIRE_BUS0);
OneWire oneWire2(ONE_WIRE_BUS2);

DallasTemperature sensors0(&oneWire0);
DallasTemperature sensors2(&oneWire2);

DeviceAddress insideThermometer;

float ds18b20_tempC;


void ds18b20_setup() {
  if (egyseg.parameterek.onewire_pin == 0) {
    sensors0.begin();
    if (!sensors0.getAddress(insideThermometer, 0)) Serial.println("Unable to find address for Device 0"); 
    sensors0.setResolution(insideThermometer, 11);   
  } else {
    sensors2.begin();
    if (!sensors2.getAddress(insideThermometer, 0)) Serial.println("Unable to find address for Device 0"); 
    sensors2.setResolution(insideThermometer, 11);
  }
}

void ds18b20_loop(float _ds18b20_hisztC) {
  if (egyseg.parameterek.onewire_pin == 0) {
      sensors0.requestTemperatures(); // Send the command to get temperatures
      ds18b20_tempC = sensors0.getTempC(insideThermometer) - _ds18b20_hisztC;
      Serial.println(ds18b20_tempC);
  } else {
      sensors2.requestTemperatures(); // Send the command to get temperatures
      ds18b20_tempC = sensors2.getTempC(insideThermometer) - _ds18b20_hisztC;
      Serial.println(ds18b20_tempC); 
  }
}
