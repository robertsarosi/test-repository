/*
 * sendController() percenként;
 */
void loopMainLepes(byte _lepesszamlalo){

    if (egyseg.aktivok.ds18b20_aktiv) ds18b20_loop(egyseg.hiszt);
    if (egyseg.aktivok.lm50c_aktiv) lm50c_loop();
    if (egyseg.aktivok.oled_aktiv) oled_loop();
    relay_loop(relay);

    
    switch (_lepesszamlalo) {
      case 5: if(!ketperc) if(egyseg.aktivok.autoUpdate_aktiv) autoUpdate_loop();
              break;
      case 30: 	if(egyseg.aktivok.autoUpdate_aktiv){
					if (urgent_update && String(ESP.getSketchMD5()) != web_hash) {
					  egyseg.updates = true;
					  saveConfig();
					  delay(100);
					  ESP.restart(); 
					} else {
					  http_req_update_hash = "Hash is correct or urgent false";
					}
				}	
              break;
      case 35: if (egyseg.aktivok.mysql_aktiv) sendmysql();
              break;
      case 50: if(ketperc) if (egyseg.aktivok.idokep_aktiv) idokep_loop();
              break;
      case 60: ketperc = !ketperc;
               if (egyseg.aktivok.controller_aktiv) sendController();
              break;
    }
}
