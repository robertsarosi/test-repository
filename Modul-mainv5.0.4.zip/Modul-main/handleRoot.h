void handleRoot() {
  String message;
  boolean serverArg_volt = false;
  

  for ( uint8_t i = 0; i < server.args(); i++ ) {
    //message += " " + server.argName ( i ) + ": " + server.arg ( i ) + "\n";
    serverArg_volt = true;

    if(server.argName(i) == "id0"){
      egyseg.id0 = server.arg(i).toInt();
    }

    if(server.argName(i) == "id1"){
      egyseg.id1 = server.arg(i).toInt();
    }
    
    if(server.argName(i) == "name"){
      egyseg.names = server.arg(i);
    }
    
    if(server.argName(i) == "szam"){
        egyseg.dbszam = server.arg(i).toInt();
    }
    
    if(server.argName(i) == "hiszt"){
        egyseg.hiszt = server.arg(i).toFloat();
    }
    if(server.argName(i) == "ds18b20"){
      if (server.arg(i) == "on") {
        egyseg.aktivok.ds18b20_aktiv = true;
      }
      if (server.arg(i) == "off") {
        egyseg.aktivok.ds18b20_aktiv = false;
      }
    }

    if(server.argName(i) == "lm50c"){
      if (server.arg(i) == "on") {
        egyseg.aktivok.lm50c_aktiv = true;
      }
      if (server.arg(i) == "off") {
        egyseg.aktivok.lm50c_aktiv = false;
      }
    }

    if(server.argName(i) == "mysql"){
      if (server.arg(i) == "on") {
        egyseg.aktivok.mysql_aktiv = true;
      }
      if (server.arg(i) == "off") {
        egyseg.aktivok.mysql_aktiv = false;
      }
    }

    if(server.argName(i) == "controller"){
      if (server.arg(i) == "on") {
        egyseg.aktivok.controller_aktiv = true;
      }
      if (server.arg(i) == "off") {
        egyseg.aktivok.controller_aktiv = false;
      }
    }

    if(server.argName(i) == "idokep"){
      if (server.arg(i) == "on") {
        egyseg.aktivok.idokep_aktiv = true;
      }
      if (server.arg(i) == "off") {
        egyseg.aktivok.idokep_aktiv = false;
      }
    }

    if(server.argName(i) == "oled"){
      if (server.arg(i) == "on") {
        egyseg.aktivok.oled_aktiv = true;
      }
      if (server.arg(i) == "off") {
        egyseg.aktivok.oled_aktiv = false;
      }
    }

    if(server.argName(i) == "onewire_pin"){
      if (server.arg(i) == "0") {
        egyseg.parameterek.onewire_pin = 0;
      }
      if (server.arg(i) == "2") {
        egyseg.parameterek.onewire_pin = 2;
      }
    }
    
    if(server.argName(i) == "relay"){
      //boolean aktiv;
      if (server.arg(i) == "on") {
        relay = true;
      }
      if (server.arg(i) == "off") {
        relay = false;
      }
    }
  }

  if (serverArg_volt) saveConfig();
  
  message ="<html><head><title>ESP8266 Demo</title></head><body><h1>Hello from ESP8266!</h1><p>Uptime: ";
  message += eltelt_ido();
  
  if (egyseg.aktivok.ds18b20_aktiv) {
    message += "</p><p>Hőmérséklet: ";
    message += String(ds18b20_tempC, 2);
  }
  if (egyseg.aktivok.lm50c_aktiv) {
    message += "</p><p>Hőmérséklet: ";
    message += String(lm50c_tempC, 2);
  }
  
  message += "</p><form action='/index.html' method='GET'>";
  message += "Id0: <input type='text' name='id0' value='" + String(egyseg.id0) + "'></br>";
  message += "Id1: <input type='text' name='id1' value='" + String(egyseg.id1) + "'></br>";
  message += "Név: <input type='text' name='name' value='" + String(egyseg.names) + "'></br>";
  message += "Homero szama: <input type='text' name='szam' value='" + String(egyseg.dbszam) + "'></br>";
  message += "Hiszterezis: <input type='text' name='hiszt' value='" + String(egyseg.hiszt, 2) + "'></br>";
  message += "One wire pin: <input type='text' name='onewire_pin' value='" + String(egyseg.parameterek.onewire_pin) + "'></br>";
  message += "Relay: <input type='hidden' name='relay' value='off'><input type='checkbox' name='relay' ";
  if (relay){
    message += "checked";
  }
  message += "></br>";
  
  message += "DS18B20 aktiv? <input type='hidden' name='ds18b20' value='off'><input type='checkbox' name='ds18b20' ";
  if (egyseg.aktivok.ds18b20_aktiv){
    message += "checked";
  }
  message += "></br>";

  message += "LM50C aktiv? <input type='hidden' name='lm50c' value='off'><input type='checkbox' name='lm50c' ";
  if (egyseg.aktivok.lm50c_aktiv){
    message += "checked";
  }
  message += "></br>";

  message += "MySql aktiv? <input type='hidden' name='mysql' value='off'><input type='checkbox' name='mysql' ";
  if (egyseg.aktivok.mysql_aktiv){
    message += "checked";
  }
  message += "></br>";

  message += "Controller aktiv? <input type='hidden' name='controller' value='off'><input type='checkbox' name='controller' ";
  if (egyseg.aktivok.controller_aktiv){
    message += "checked";
  }
  message += "></br>";

  message += "Idokep aktiv? <input type='hidden' name='idokep' value='off'><input type='checkbox' name='idokep' ";
  if (egyseg.aktivok.idokep_aktiv){
    message += "checked";
  }
  message += "></br>";

  message += "Oled aktiv? <input type='hidden' name='oled' value='off'><input type='checkbox' name='oled' ";
  if (egyseg.aktivok.oled_aktiv){
    message += "checked";
  }
  message += "></br>";

  message += "O az aktiv: <input type='checkbox' name='aktiv'>";
  message += "</br>";
  message += "<button submit='Send' name='send' value='send'>Send</button></form></body></html>";

  server.send ( 200, "text/html", message );
}
