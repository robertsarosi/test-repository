
//const char* ssid = "robis";
//const char* password = "Conti1981";

///////////////////////////////////////////////////////
struct moduls {
  boolean ds18b20_aktiv;
  boolean lm50c_aktiv;
  boolean controller_aktiv;
  boolean idokep_aktiv;
  boolean mysql_aktiv;
  boolean oled_aktiv;
  boolean autoUpdate_aktiv;
};

struct moduls_param {
  byte onewire_pin;
  String ssid;
  String passw;
  String idokep_user;
  String idokep_passw;
  String autoUpdate_host;
  String autoUpdate_url;
  String autoUpdate_name;
};

struct homeros {
  int id0;
  byte id1;
  String names;
  String data_type;
  float fdata;
  String sdata;
  int idata;
  long ldata;
  bool bdata;
  int dbszam;
  byte dbszam_bit;
  float hiszt;
  boolean aktiv;
  boolean updates;
  String mysql_path;
  String mysql_data;
  struct moduls aktivok;
  struct moduls_param parameterek;
};



struct homeros egyseg;
//struct homeros egyseg2;

////////////////////////////////////////////////////////////

#define DBG_OUTPUT_PORT Serial
File fsUploadFile;
#define interval 1000

long timeSinceLastModeSwitch = 0;
byte lepesszamlalo;


ESP8266WebServer server(80);
WiFiClient client1;


bool ketperc = false;
