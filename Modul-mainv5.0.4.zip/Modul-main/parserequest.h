void parseRequest(String req_) {
      Serial.print(req_);
         int val;
//          if (req_.indexOf("B5.3=1") != -1) {
//            valtozott = true;
//            valArea = "S7AreaMK";
//            valByte = 5;
//            valBit = 3;
//            valErtek = true;
//            Serial.println("B5.3=1");}
//          else if (req_.indexOf("B5.3=0") != -1) {
//            valtozott = true;
//            valArea = "S7AreaMK";
//            valByte = 5;
//            valBit = 3;
//            valErtek = false;
//            Serial.println("B5.3=0"); }
//          else if (req_.indexOf("B0.0=0") != -1) {
//            valtozott = true;
//            valArea = "S7AreaDB";
//            valByte = 0;
//            valBit = 0;
//            valErtek = false;
//            Serial.println("B0.0=0"); }
//          else if (req_.indexOf("B0.1=0") != -1) {
//            valtozott = true;
//            valArea = "S7AreaDB";
//            valByte = 0;
//            valBit = 1;
//            valErtek = false;
//            Serial.println("B0.1=0"); }
//          else if (req_.indexOf("B0.0=1") != -1) {
//            valtozott = true;
//            valArea = "S7AreaDB";
//            valByte = 0;
//            valBit = 2;
//            valErtek = true;
//            Serial.println("B0.0=1"); }
//          else if (req_.indexOf("B0.1=1") != -1) {
//            valtozott = true;
//            valArea = "S7AreaDB";
//            valByte = 0;
//            valBit = 3;
//            valErtek = true;
//            Serial.println("B0.1=1"); }
//          else if (req_.indexOf("E0.0=1") != -1) {
//            //error2 = 0;
//            Serial.println("E0.0=1"); }
//          else {
//            
//          }
}
