String http_request_update;
String web_version = "N/A";
String web_hash = "N/A";
String http_req_update_hash = "N/A";
//String autoUpdate_host = "berobiskazan.hu";
//String autoUpdate_url = "/esp8266/Modul/";
bool urgent_update = false;

void update_started() {
  Serial.println("CALLBACK:  HTTP update process started");
}

void update_finished() {
  Serial.println("CALLBACK:  HTTP update process finished");
}

void update_progress(int cur, int total) {
  Serial.printf("CALLBACK:  HTTP update process at %d of %d bytes...\n", cur, total);
}

void update_error(int err) {
  Serial.printf("CALLBACK:  HTTP update fatal error code %d\n", err);
}

void autoUpdate_setup(){
  WiFiClient client2;

    ESPhttpUpdate.onStart(update_started);
    ESPhttpUpdate.onEnd(update_finished);
    ESPhttpUpdate.onProgress(update_progress);
    ESPhttpUpdate.onError(update_error);

    egyseg.updates = false;
    saveConfig();
    
    t_httpUpdate_return ret = ESPhttpUpdate.update(client2, "http://" + egyseg.parameterek.autoUpdate_host + egyseg.parameterek.autoUpdate-url + "/esp.php", egyseg.parameterek.autoUpdate_name, ver); //"http://berobiskazan.hu/esp8266/Modul/esp.php", "Modul", ver
    
    
    switch (ret) {
      case HTTP_UPDATE_FAILED:
        Serial.printf("HTTP_UPDATE_FAILD Error (%d): %s\n", ESPhttpUpdate.getLastError(), ESPhttpUpdate.getLastErrorString().c_str());
        http_request_update = "HTTP_UPDATE_FAILD Error (" + String(ESPhttpUpdate.getLastError()) + "): " + String(ESPhttpUpdate.getLastErrorString()) + "\n";
        break;

      case HTTP_UPDATE_NO_UPDATES:
        Serial.println("HTTP_UPDATE_NO_UPDATES");
        http_request_update = "HTTP_UPDATE_NO_UPDATES";
        break;

      case HTTP_UPDATE_OK:
        Serial.println("HTTP_UPDATE_OK");
        http_request_update = "HTTP_UPDATE_OK";
        break;
    }
}

void autoUpdate_loop() {
      client1.stop();          
      if (client1.connect(egyseg.parameterek.autoUpdate_host, 80)) {
        String url = egyseg.parameterek.autoUpdate_url;
        url += egyseg.parameterek.autoUpdate_name".ver"; //Modul
        client1.print(String("GET ") + url + " HTTP/1.1\r\n" +
                     "Host: " + egyseg.parameterek.autoUpdate_host + "\r\n" + 
                     "Connection: keep-alive\r\n" +
                     "Cache-Control: max-age=0\r\n"+
                     "Upgrade-Insecure-Requests: 1\r\n" +
                     "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36\r\n" +
                     "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8\r\n" +
                     "\r\n");
      } else {Serial.println("connection failed"); client1.stop(); WiFiClient client1;} 
}
