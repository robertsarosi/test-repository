<?php
	function logincheck (){
		//session_start();
		if(!isset($_SESSION['belepve'])){
			header("Location: ..\index.php");
		}
		if($_SESSION['belepve'] != 1){
			echo '<script> alert("Nem OK");</script>';
		}
	}
?>