void sendController(){
      client1.stop();
      if (client1.connect("controller.lan", 80)) {       
        String url = "/addmodule.php?";
        String message;

        url += String(egyseg.names) + "=";
        DynamicJsonDocument doc(300);
        doc[String(egyseg.names)]["id0"] = String(egyseg.id0);
        doc[String(egyseg.names)]["id1"] = String(egyseg.id1);
        doc[String(egyseg.names)]["names"] = String(egyseg.names);
        doc[String(egyseg.names)]["data_type"] = String(egyseg.data_type);
        doc[String(egyseg.names)]["data"] = String(ds18b20_tempC, 2); //egyseg.fdata
        doc[String(egyseg.names)]["dbszam"] = String(egyseg.dbszam);
        doc[String(egyseg.names)]["dbszam_bit"] = String(egyseg.dbszam_bit);
        doc[String(egyseg.names)]["ip"] = WiFi.localIP();
        doc[String(egyseg.names)]["ver"] = String(ver);

        serializeJson(doc, message);

          url += message;
          
//        url += String(egyseg.names) + "[szama]=" + String(egyseg.dbszam);
//        url += "&" + String(egyseg.names) + "[name]=" + String(egyseg.names);
//        url += "&" + String(egyseg.names) + "[data]=";
//        url += String(ds18b20_tempC,3);
        
        client1.print(String("GET ") + url + " HTTP/1.1\r\n" +
                     "Host: " + host + "\r\n" + 
                     "Connection: keep-alive\r\n" +
                     "Cache-Control: max-age=0\r\n"+
                     "Upgrade-Insecure-Requests: 1\r\n" +
                     "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36\r\n" +
                     "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8\r\n" +
                     "\r\n");
      } else {Serial.println("connection failed"); client1.stop(); WiFiClient client1;}
}
