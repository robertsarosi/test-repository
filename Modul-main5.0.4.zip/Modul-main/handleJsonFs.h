
bool loadConfig() {
//  struct homeros {
//  int id0;
//  byte id1;
//  String names;
//  float fdata;
//  String sdata;
//  int idata;
//  int dbszam;
//  float hiszt;
//  boolean aktiv;
//  boolean idokep_aktiv;
//  boolean mysql_aktiv;
//  String mysql_path;
//  String mysql_data;
//  boolean ds18b20_aktiv;
//  boolean lm50c_aktiv;
//  boolean controller_aktiv;
//};
  File configFile = SPIFFS.open("/beallitasok.json", "r");
  if (!configFile) {
    Serial.println("Failed to open config file");
    return false;
  }

  size_t size = configFile.size();

  DynamicJsonDocument doc(8192);

  DeserializationError error = deserializeJson(doc, configFile);

  egyseg.id0 = doc["id0"];
  egyseg.id1 = doc["id1"];
  egyseg.names = doc["names"].as<String>();
  egyseg.data_type = doc["data_type"].as<String>();
  egyseg.dbszam = doc["dbszam"];
  egyseg.dbszam_bit = doc["dbszam_bit"];
  egyseg.hiszt = doc["hiszt"];
  egyseg.aktiv = doc["aktiv"];
  egyseg.updates = doc["updates"];
  egyseg.mysql_path = doc["mysql_path"].as<String>();
  egyseg.mysql_data = doc["mysql_data"].as<String>();
  
  egyseg.aktivok.idokep_aktiv = doc["aktivok"]["idokep_aktiv"];
  egyseg.aktivok.mysql_aktiv = doc["aktivok"]["mysql_aktiv"];
  egyseg.aktivok.ds18b20_aktiv = doc["aktivok"]["ds18b20_aktiv"];
  egyseg.aktivok.lm50c_aktiv = doc["aktivok"]["lm50c_aktiv"];
  egyseg.aktivok.controller_aktiv = doc["aktivok"]["controller_aktiv"];
  egyseg.aktivok.oled_aktiv = doc["aktivok"]["oled_aktiv"];
  egyseg.aktivok.autoUpdate_aktiv = true; //doc["aktivok"]["autoUpdate_aktiv"];

  egyseg.parameterek.onewire_pin = doc["parameterek"]["onewire_pin"];
  egyseg.parameterek.ssid = "robis"; //doc["parameterek"]["ssid"];
  egyseg.parameterek.passw = "Conti1981"; //doc["parameterek"]["passw"];
  egyseg.parameterek.idokep_user = "robertsarosi"; //doc["parameterek"]["idokep_user"];
  egyseg.parameterek.idokep_passw = "Conti1981"; //doc["parameterek"]["idokep_passw"];
  egyseg.parameterek.autoUpdate_host = "berobiskazan.hu"; //doc["parameterek"]["autoUpdate_host"];
  egyseg.parameterek.autoUpdate_url = "/esp8266/Modul/"; //doc["parameterek"]["autoUpdate_url"];
  egyseg.parameterek.autoUpdate_name = "Modul"; //doc["parameterek"]["autoUpdate_name"];
    
  return true;
}

bool saveConfig() {
//  byte id0;
//  byte id1;
//  char* names;
//  byte inputszam;
//  byte outputszam;
//  byte analogueszam;
//  byte merkelbitszam;
//  byte merkelbyteszam;
//  byte merkelworldszam;
//  byte homeroszam;
//  boolean aktiv;


  File configFile = SPIFFS.open("/beallitasok.json", "w");
  if (!configFile) {
    Serial.println("Failed to open config file for writing");
    return false;
  }
  DynamicJsonDocument doc(8192);

    doc["id0"] = egyseg.id0;
    doc["id1"] = egyseg.id1;
    doc["names"] = egyseg.names;
    doc["dbszam"] = egyseg.dbszam;
    doc["data_type"] = egyseg.data_type;
    doc["dbszam_bit"] = egyseg.dbszam_bit;
    doc["hiszt"]= egyseg.hiszt;
    doc["aktiv"] = egyseg.aktiv;
    doc["updates"] = egyseg.updates;
    doc["mysql_path"] = egyseg.mysql_path;
    doc["mysql_data"] = egyseg.mysql_data;
    
    doc["aktivok"]["idokep_aktiv"] = egyseg.aktivok.idokep_aktiv;
    doc["aktivok"]["mysql_aktiv"] = egyseg.aktivok.mysql_aktiv;
    doc["aktivok"]["ds18b20_aktiv"] = egyseg.aktivok.ds18b20_aktiv;
    doc["aktivok"]["lm50c_aktiv"] = egyseg.aktivok.lm50c_aktiv;
    doc["aktivok"]["controller_aktiv"] = egyseg.aktivok.controller_aktiv;
    doc["aktivok"]["oled_aktiv"] = egyseg.aktivok.oled_aktiv;
	doc["aktivok"]["autoUpdate_aktiv"] = egyseg.aktivok.autoUpdate_aktiv;

    doc["parameterek"]["onewire_pin"] = egyseg.parameterek.onewire_pin;
	doc["parameterek"]["ssid"] = egyseg.parameterek.ssid;
	doc["parameterek"]["passw"] = egyseg.parameterek.passw;
	doc["parameterek"]["idokep_user"] = egyseg.parameterek.idokep_user;
	doc["parameterek"]["idokep_passw"] = egyseg.parameterek.idokep_passw;
	doc["parameterek"]["autoUpdate_host"] = egyseg.parameterek.autoUpdate_host;
	doc["parameterek"]["autoUpdate_url"] = egyseg.parameterek.autoUpdate_url;
	doc["parameterek"]["autoUpdate_name"] = egyseg.parameterek.autoUpdate_name;
     
  // Serialize JSON to file
  if (serializeJsonPretty(doc, configFile) == 0) {
    Serial.println("Failed to write to file");
  }

  return true;
}
