void setCrossOrigin(){
    server.sendHeader(F("Access-Control-Allow-Origin"), F("*"));
    server.sendHeader(F("Access-Control-Max-Age"), F("600"));
    server.sendHeader(F("Access-Control-Allow-Methods"), F("PUT,POST,GET,OPTIONS"));
    server.sendHeader(F("Access-Control-Allow-Headers"), F("*"));
};

void setupServer(){
  
  /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  server.on("/list", HTTP_GET, handleFileList);
  server.on("/edit", HTTP_GET, [](){
    if(!handleFileRead("/edit.htm")) server.send(404, "text/plain", "FileNotFound");
  });
  server.on("/edit", HTTP_PUT, handleFileCreate);
  server.on("/edit", HTTP_DELETE, handleFileDelete);
  server.on("/edit", HTTP_POST, [](){ server.send(200, "text/plain", ""); }, handleFileUpload);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

  server.on ( "/", handleRoot );
  server.on ( "/index.html", handleRoot);
  server.on ( "/version.php", handleVer);
  server.on ( "/egysegeklekeres.php", handleEgysegek_Lekeres);
  server.on ( "/restart.php", pageRestart);
  server.on ( "/test.svg", drawGraph );
  server.on ( "/inline", []() {
    server.send ( 200, "text/plain", "this works as well" );
  } );
  server.onNotFound([](){
    if(!handleFileRead(server.uri()))
      server.send(404, "text/plain", "FileNotFound");
  });

  server.begin();
}
