int lm50c_Pin = A0;
int lm50c_Value;

float lm50c_tempC;

void lm50c_setup() {
  ;
}

void lm50c_loop() {
  lm50c_Value = analogRead(lm50c_Pin);
  lm50c_tempC = (3300 / 1024.0 * lm50c_Value - 500) / 10.0;
}
