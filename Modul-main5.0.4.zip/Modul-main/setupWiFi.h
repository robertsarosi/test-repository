
void setupWiFi(){  
  WiFi.mode(WIFI_STA);
  WiFi.begin(egyseg.parameterek.ssid, egyseg.parameterek.passw); //ssid, password);

  while(WiFi.waitForConnectResult() != WL_CONNECTED){
    WiFi.begin(ssid, password);
    Serial.println("WiFi failed, retrying.");
  }

  MDNS.begin(egyseg.names);
  WiFi.hostname(egyseg.names);


  MDNS.addService("http", "tcp", 80);
  
}
